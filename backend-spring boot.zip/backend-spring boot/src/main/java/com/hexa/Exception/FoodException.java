package com.hexa.Exception;

public class FoodException extends Exception {

	public FoodException(String message) {
		super(message);

	}

}
