package com.hexa.Exception;

public class ReviewException extends Exception {

	public ReviewException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
