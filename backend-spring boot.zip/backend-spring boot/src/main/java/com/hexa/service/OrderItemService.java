package com.hexa.service;

import com.hexa.model.OrderItem;

public interface OrderItemService {
	
	public OrderItem createOrderIem (OrderItem orderItem);

}
