package com.hexa.service;

import com.hexa.model.CartItem;

public interface CartItemService {
	
	public CartItem createCartItem(CartItem item);

}
